
package com.example.Ejercicios;


import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;


@Slf4j
public class Iniciar{ 
    
    @GetMapping
        public void index(){
            log.info(" INFO ");
            log.warn(" WARN ");
            log.error(" ERROR ");
            log.trace(" TRACE ");
            log.debug(" DEBUG ");
            System.out.println("Se muestra hasta el nivel de ERROR.");
        }
}
