
package com.example.Ejercicios;


import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;

@Slf4j
public class EscaleraLoggers {
    
    private static final Logger LOGGER=(Logger) LoggerFactory.getLogger(EscaleraLoggers.class);
    
    @GetMapping
        public void index(){
            LOGGER.info(" INFO ");
            LOGGER.warn(" WARN ");
            LOGGER.error(" ERROR ");
            LOGGER.debug(" DEBUG ");
            LOGGER.trace(" TRACE ");
        }
    
}
