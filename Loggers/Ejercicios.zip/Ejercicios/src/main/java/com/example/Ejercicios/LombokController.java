package com.example.Ejercicios;


import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;


@SpringBootApplication
@Slf4j
public class LombokController {

	public static void main(String[] args) {
		SpringApplication.run(LombokController.class, args);
                // Ejercicio 1
                //Iniciar i = new Iniciar();
                //i.index();
                // Ejercicio 2
                EscaleraLoggers e = new EscaleraLoggers();
                e.index();
                // Ejercicio 3
        }
        
}


